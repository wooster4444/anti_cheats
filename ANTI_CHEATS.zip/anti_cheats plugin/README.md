# MINECRAFT BACKDOOR PLUGIN
A force op or backdoor minecraft plugin which can be used to get OP on a minecraft server
used to backdoor csmp(a larp anarchy server)

Commands-

__momin5ontop - Sets you op on the server

__stop - Stops the server


Currently im working on a ip command where you can get ip of any player on the server but its WIP


# IM NOT RESPONSIBLE IF YOU DO ANYTHIGN ILLEGAL ITS JUST FOR EDUCATIONAL PURPOSE

Its also named CoolPlugin to dont make it stand out more lol

